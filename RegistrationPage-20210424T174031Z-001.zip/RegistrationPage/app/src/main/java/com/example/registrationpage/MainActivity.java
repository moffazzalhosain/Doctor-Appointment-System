package com.example.registrationpage;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    EditText e1,e2;
    private Button signInButton, signUpButton;
    DataBaseHelper sqLiteDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sqLiteDatabase = new DataBaseHelper(this);
        signInButton = (Button) findViewById(R.id.d1);
        signUpButton = (Button) findViewById(R.id.d2);
        e1=(EditText)findViewById(R.id.u);
        e2=(EditText)findViewById(R.id.pp);
        signInButton.setOnClickListener(this);
        signUpButton.setOnClickListener(this);

    }

    public void onClick(View view) {
        String UserName=e1.getText().toString();
        String password=e2.getText().toString();


        if (view.getId()== R.id.d1) {
            Boolean UserNamePassword=sqLiteDatabase.chkUserNamePassword(UserName,password);
            if(UserNamePassword==true){
                Intent intent = new Intent(MainActivity.this, ViewAppointment.class);
                startActivity(intent);
            }else{
                Toast.makeText(getApplicationContext(),"UserName ans password did not match",Toast.LENGTH_LONG).show();

            }
        }
        else if (view.getId() == R.id.d2) {
            Intent intent = new Intent(MainActivity.this,SignUp.class);
            startActivity(intent);

        }
    }
}